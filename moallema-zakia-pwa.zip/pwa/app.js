/* ============ Data (loaded async for PWA/static hosting) ============ */
var DATA = null;
var GUIDE = [
  'assets/guide/01.jpg','assets/guide/02.jpg','assets/guide/03.jpg','assets/guide/04.jpg','assets/guide/05.jpg',
  'assets/guide/06.jpg','assets/guide/07.jpg','assets/guide/08.jpg','assets/guide/09.jpg','assets/guide/10.jpg'
];
var FLAT = [];

var ICONS = {
  search: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/><path d="M21 21l-4.3-4.3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  back: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  chev: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  eye: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7z" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.8"/></svg>',
  puzzle: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M9 4h4a1 1 0 011 1v2.2a1.6 1.6 0 002.6 1.25A2 2 0 0121 10a2 2 0 01-4.4 1.55A1.6 1.6 0 0014 13.8V16a1 1 0 01-1 1H9a1 1 0 01-1-1v-2.2a1.6 1.6 0 00-2.6-1.25A2 2 0 013 10a2 2 0 014.4-1.55A1.6 1.6 0 009 6.2V5a1 1 0 011-1z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
  gear: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3.2" stroke="currentColor" stroke-width="1.8"/><path d="M12 3v2.2M12 18.8V21M21 12h-2.2M5.2 12H3M18 6l-1.5 1.5M7.5 16.5L6 18M18 18l-1.5-1.5M7.5 7.5L6 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
  clipboard: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="5" y="4" width="14" height="17" rx="2" stroke="currentColor" stroke-width="1.8"/><path d="M9 4V3a1 1 0 011-1h4a1 1 0 011 1v1" stroke="currentColor" stroke-width="1.8"/><path d="M8.5 11h7M8.5 15h5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
  heart: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M12 20s-7.5-4.6-9.6-9.4C1 7 2.7 3.8 6 3.2c2-.4 3.9.5 5 2 .1.1.9.1 1 0 1.1-1.5 3-2.4 5-2 3.3.6 5 3.8 3.6 7.4C19.5 15.4 12 20 12 20z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
  chat: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M21 12a8 8 0 01-11.4 7.2L4 20l1.1-4.3A8 8 0 1121 12z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M8 11h8M8 14h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  image: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="2.4" stroke="currentColor" stroke-width="1.8"/><circle cx="9" cy="10" r="1.6" stroke="currentColor" stroke-width="1.6"/><path d="M21 16l-5.5-5-8.5 7" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
  star: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 2.8l2.7 5.9 6.3.7-4.7 4.4 1.3 6.4L12 17l-5.6 3.2 1.3-6.4-4.7-4.4 6.3-.7L12 2.8z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>',
  copy: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><rect x="8" y="8" width="12" height="12" rx="2" stroke="currentColor" stroke-width="2"/><path d="M16 8V6a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2" stroke="currentColor" stroke-width="2"/></svg>',
  check: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};

var CAT_META = {
  tamheed:   { icon:'eye',       bg:'#EAF0EE' },
  activities:{ icon:'puzzle',    bg:'#F2ECDD' },
  wasael:    { icon:'gear',      bg:'#E9EEF2' },
  taqweem:   { icon:'clipboard', bg:'#EFEAE0' },
  daam:      { icon:'heart',     bg:'#F3E7E4' },
  prompts:   { icon:'chat',      bg:'#E7EEEA' }
};

/* ============ Build flat index for search + siblings ============ */
function buildIndex(){
  FLAT = [];
  DATA.categories.forEach(function(cat){
    if (cat.id === 'about') return;
    if (cat.groups) {
      cat.groups.forEach(function(g){
        g.items.forEach(function(it, i){
          FLAT.push({ catId: cat.id, catName: cat.name, groupName: g.group_name, groupId: g.id, item: it, siblings: g.items, idx: i });
        });
      });
    } else if (cat.items) {
      cat.items.forEach(function(it, i){
        FLAT.push({ catId: cat.id, catName: cat.name, groupName: null, groupId: null, item: it, siblings: cat.items, idx: i });
      });
    }
  });
}

function findEntry(catId, groupId, code){
  for (var i=0;i<FLAT.length;i++){
    var e = FLAT[i];
    if (e.catId===catId && (groupId ? e.groupId===groupId : true) && e.item.code===code) return e;
  }
  return null;
}

/* ============ Navigation stack ============ */
var stack = [{ type:'home' }];

function push(view){ stack.push(view); render(); window.scrollTo(0,0); }
function replaceTop(view){ stack[stack.length-1] = view; render(); }
function goBack(){ if (stack.length>1){ stack.pop(); render(); window.scrollTo(0,0);} }
function goHome(){ stack = [{type:'home'}]; render(); window.scrollTo(0,0); }

/* ============ Helpers ============ */
function stripTags(html){
  var d = document.createElement('div');
  d.innerHTML = html || '';
  return (d.textContent || '').replace(/\s+/g,' ').trim();
}
function excerpt(html, n){
  var d = document.createElement('div');
  d.innerHTML = html || '';
  d.querySelectorAll('h4').forEach(function(h){ h.remove(); });
  var t = (d.textContent || '').replace(/\s+/g,' ').trim();
  if (!t) return '';
  return t.length > n ? t.slice(0,n) + '…' : t;
}
function esc(s){
  return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function fmtTitle(s){
  var e = esc(s);
  // isolate parenthetical Latin fragments so bidi doesn't mangle wrapping
  return e.replace(/\(([^()]*[A-Za-z][^()]*)\)/g, '<span dir="ltr" style="unicode-bidi:isolate">($1)</span>');
}
function icon(name){ return ICONS[name] || ''; }

var toastTimer = null;
function showToast(msg){
  var t = document.getElementById('toast');
  t.innerHTML = icon('check') + '<span>'+msg+'</span>';
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ t.classList.remove('show'); }, 1700);
}

function copyPrompt(text, btn){
  var done = function(){
    btn.classList.add('copied');
    btn.innerHTML = icon('check') + '<span>تم النسخ</span>';
    showToast('تم نسخ البرومبت، جاهز للصق في أداة الذكاء الاصطناعي');
    setTimeout(function(){
      btn.classList.remove('copied');
      btn.innerHTML = icon('copy') + '<span>نسخ البرومبت</span>';
    }, 1800);
  };
  if (navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(text).then(done).catch(function(){ fallbackCopy(text, done); });
  } else {
    fallbackCopy(text, done);
  }
}
function fallbackCopy(text, cb){
  var ta = document.createElement('textarea');
  ta.value = text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.focus(); ta.select();
  try { document.execCommand('copy'); } catch(e){}
  document.body.removeChild(ta);
  cb();
}

/* ============ Renderers ============ */
var app = document.getElementById('app');

function render(){
  var view = stack[stack.length-1];
  var html = '';
  if (view.type === 'home') html = renderHome();
  else if (view.type === 'category') html = renderCategory(view);
  else if (view.type === 'item') html = renderItem(view);
  else if (view.type === 'search') html = renderSearch(view);
  else if (view.type === 'guide') html = renderGuide();
  else if (view.type === 'about') html = renderAbout();
  app.innerHTML = html;
  wireEvents(view);
}

function renderHome(){
  var cats = DATA.categories.filter(function(c){ return c.id !== 'about'; });
  var rows = cats.map(function(c){
    var meta = CAT_META[c.id] || {icon:'star', bg:'#EEE'};
    var count = c.groups ? c.groups.reduce(function(s,g){return s+g.items.length;},0) : (c.items? c.items.length:0);
    return '<div class="cat-row" data-nav="category" data-cat="'+c.id+'">' +
      '<div class="cat-icon" style="background:'+meta.bg+'">'+icon(meta.icon)+'</div>' +
      '<div class="cat-main"><h3>'+fmtTitle(c.name)+'</h3><p>'+esc(c.subtitle)+'</p></div>' +
      '<div class="cat-count">'+count+'</div>' +
      '<svg class="row-chev" width="16" height="16" viewBox="0 0 24 24" fill="none" style="color:var(--muted);transform:scaleX(-1)"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
    '</div>';
  }).join('');

  return '' +
  '<div class="hero">' +
    '<div class="hero-top">' +
      '<div class="brand">' +
        '<div class="brand-mark">م</div>' +
        '<div class="brand-text"><h1>منصة المعلمة الذكية</h1><p>جمعية من أحياها</p></div>' +
      '</div>' +
    '</div>' +
    '<div class="hero-title">كل ما تحتاجينه لتحضير حصة متكاملة<br>في أقل من ٥ دقائق</div>' +
    '<div class="hero-sub">تمهيد، نشاط، وسيلة، تقويم، دعم وإثراء — منظمة وجاهزة للاستخدام</div>' +
    '<div class="search-box" data-nav="search">' + icon('search') +
      '<input type="text" placeholder="ابحث في كل البنوك... مثال: بطاقة خروج" readonly>' +
    '</div>' +
  '</div>' +
  '<div id="content">' +
    '<div class="section-label">بنوك المنصة</div>' +
    '<div class="row-list" style="margin-bottom:18px">' + rows + '</div>' +
    '<div class="link-row" data-nav="guide">' +
      '<div class="link-row-left">'+icon('image')+'<span>دليل الاستخدام الشامل</span></div>' +
      '<svg class="chev" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
    '</div>' +
    '<div class="link-row" data-nav="about">' +
      '<div class="link-row-left">'+icon('star')+'<span>عن المشروع والجمعية</span></div>' +
      '<svg class="chev" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
    '</div>' +
  '</div>';
}

function pageHead(eyebrow, title){
  return '<div class="page-head">' +
    '<div class="back" data-back="1">'+icon('back')+'</div>' +
    '<div class="page-head-text">' + (eyebrow?'<p class="eyebrow">'+esc(eyebrow)+'</p>':'') + '<h2>'+fmtTitle(title)+'</h2></div>' +
  '</div>';
}

function renderCategory(view){
  var cat = DATA.categories.filter(function(c){return c.id===view.cat;})[0];
  if (!cat) return pageHead('', 'غير موجود') + '<div id="content"></div>';
  var body = '';
  if (cat.groups){
    cat.groups.forEach(function(g){
      var rows = g.items.map(function(it){ return itemRow(cat.id, g.id, it); }).join('');
      body += '<div class="group-title"><span class="dot"></span>'+esc(g.group_name)+'</div>' +
              '<div class="row-list">'+rows+'</div>';
    });
  } else if (cat.items){
    var rows = cat.items.map(function(it){ return itemRow(cat.id, null, it); }).join('');
    body += '<div class="row-list" style="margin-top:6px">'+rows+'</div>';
  }
  return pageHead('بنوك المنصة', cat.name) + '<div id="content">'+body+'</div>';
}

function itemRow(catId, groupId, it){
  var sub = excerpt(it.intro || it.prompt_html || '', 42);
  return '<div class="row" data-nav="item" data-cat="'+catId+'" data-group="'+(groupId||'')+'" data-code="'+it.code+'">' +
    '<div class="row-badge code">'+esc(it.code||'•')+'</div>' +
    '<div class="row-main"><h3>'+fmtTitle(it.title)+'</h3>'+(sub?'<p>'+esc(sub)+'</p>':'')+'</div>' +
    '<svg class="row-chev" width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
  '</div>';
}

function renderItem(view){
  var entry = findEntry(view.cat, view.group, view.code);
  if (!entry) return pageHead('', 'غير موجود') + '<div id="content"></div>';
  var it = entry.item;
  var eyebrow = entry.groupName ? entry.catName+' › '+entry.groupName : entry.catName;

  var promptBlock = '';
  if (it.prompt_html){
    promptBlock = '<div class="prompt-card">' +
      '<div class="prompt-card-head">' +
        '<div class="ph-title">🤖 <span>البرومبت الجاهز</span></div>' +
        '<button class="copy-btn" data-copy="1">'+icon('copy')+'<span>نسخ البرومبت</span></button>' +
      '</div>' + it.prompt_html + '</div>';
  }

  var hasPrev = entry.idx > 0;
  var hasNext = entry.idx < entry.siblings.length - 1;

  var reader = '<div class="reader">' +
      '<div class="reader-eyebrow">'+(it.code?'<span class="badge">'+esc(it.code)+'</span>':'')+'</div>' +
      '<h2 class="title">'+fmtTitle(it.title)+'</h2>' +
      (it.intro || '') +
      promptBlock +
    '</div>';

  var pager = '<div class="pager">' +
      '<button data-page="next" '+(hasNext?'':'disabled')+'>التالي <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
      '<button data-page="prev" '+(hasPrev?'':'disabled')+'><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg> السابق</button>' +
    '</div>';

  return pageHead(eyebrow, it.title) + '<div id="content" data-cat="'+entry.catId+'" data-group="'+(entry.groupId||'')+'">'+reader+pager+'</div>';
}

function renderSearch(view){
  var q = (view.q || '').trim();
  var head = '<div class="page-head">' +
      '<div class="back" data-back="1">'+icon('back')+'</div>' +
      '<div class="search-box" style="flex:1;box-shadow:none;background:rgba(244,239,223,.14)">' +
        '<span style="color:#F4EFDF">'+icon('search')+'</span>' +
        '<input id="search-input" type="text" placeholder="ابحث عن نشاط، وسيلة، أو برومبت..." value="'+esc(q)+'" style="color:#F4EFDF">' +
      '</div>' +
    '</div>';

  var resultsHtml = '';
  if (q.length < 2){
    resultsHtml = '<div class="search-empty">اكتبي كلمتين على الأقل للبحث<br>مثل: «بطاقة خروج» أو «لعبة»</div>';
  } else {
    var qn = q.toLowerCase();
    var hits = FLAT.filter(function(e){
      var hay = (e.item.title + ' ' + stripTags(e.item.intro||'') + ' ' + stripTags(e.item.prompt_html||'')).toLowerCase();
      return hay.indexOf(qn) !== -1;
    }).slice(0, 40);
    if (!hits.length){
      resultsHtml = '<div class="search-empty">لا توجد نتائج لـ «'+esc(q)+'»</div>';
    } else {
      resultsHtml = '<div class="search-results">' + hits.map(function(e){
        var path = e.groupName ? e.catName+' › '+e.groupName : e.catName;
        var sub = excerpt(e.item.intro || e.item.prompt_html || '', 60);
        return '<div class="search-hit" data-nav="item" data-cat="'+e.catId+'" data-group="'+(e.groupId||'')+'" data-code="'+e.item.code+'">' +
          '<div class="path">'+esc(path)+'</div>' +
          '<h4>'+fmtTitle(e.item.title)+'</h4>' +
          '<p>'+esc(sub)+'</p>' +
        '</div>';
      }).join('') + '</div>';
    }
  }
  return head + '<div id="content" style="padding-top:16px">'+resultsHtml+'</div>';
}

function renderGuide(){
  var imgs = GUIDE.map(function(src, i){
    return '<div class="guide-shot"><img src="'+src+'" loading="lazy" alt="خطوة '+(i+1)+'"></div>';
  }).join('');
  var textGuide = DATA.guide_text ? '<div class="reader">'+DATA.guide_text+'</div>' : '';
  return pageHead('', 'دليل الاستخدام') +
    '<div id="content">' + textGuide +
      '<div class="section-label" style="margin-top:22px">شاشات المنصة خطوة بخطوة</div>' + imgs +
    '</div>';
}

function renderAbout(){
  var cat = DATA.categories.filter(function(c){return c.id==='about';})[0];
  var blocks = (cat? cat.items : []).map(function(it){
    return '<div class="reader"><h2 class="title" style="font-size:19px">'+esc(it.title)+'</h2>' + (it.intro||'') + '</div>';
  }).join('');
  return pageHead('', 'عن المشروع') +
    '<div id="content">' +
      '<div class="about-hero"><div class="mark">م</div><h2>منصة المعلمة الذكية</h2><p>AI Teacher Toolkit — جمعية من أحياها</p></div>' +
      blocks +
    '</div>';
}

/* ============ Event wiring ============ */
function wireEvents(view){
  app.querySelectorAll('[data-back]').forEach(function(el){
    el.addEventListener('click', goBack);
  });
  app.querySelectorAll('[data-nav="category"]').forEach(function(el){
    el.addEventListener('click', function(){ push({type:'category', cat: el.getAttribute('data-cat')}); });
  });
  app.querySelectorAll('[data-nav="item"]').forEach(function(el){
    el.addEventListener('click', function(){
      push({type:'item', cat: el.getAttribute('data-cat'), group: el.getAttribute('data-group')||null, code: el.getAttribute('data-code')});
    });
  });
  var searchTrigger = app.querySelector('.search-box[data-nav="search"]');
  if (searchTrigger) searchTrigger.addEventListener('click', function(){ push({type:'search', q:''}); });
  var guideTrigger = app.querySelector('[data-nav="guide"]');
  if (guideTrigger) guideTrigger.addEventListener('click', function(){ push({type:'guide'}); });
  var aboutTrigger = app.querySelector('[data-nav="about"]');
  if (aboutTrigger) aboutTrigger.addEventListener('click', function(){ push({type:'about'}); });

  var input = document.getElementById('search-input');
  if (input){
    input.focus();
    input.addEventListener('input', function(){
      stack[stack.length-1] = { type:'search', q: input.value };
      render();
      var i2 = document.getElementById('search-input');
      if (i2){ i2.focus(); i2.setSelectionRange(i2.value.length, i2.value.length); }
    });
  }

  var copyBtn = app.querySelector('[data-copy]');
  if (copyBtn){
    copyBtn.addEventListener('click', function(){
      var entry = findEntry(view.cat, view.group, view.code);
      if (entry && entry.item.prompt_text) copyPrompt(entry.item.prompt_text, copyBtn);
    });
  }

  app.querySelectorAll('[data-page]').forEach(function(el){
    el.addEventListener('click', function(){
      if (el.disabled) return;
      var dir = el.getAttribute('data-page');
      var entry = findEntry(view.cat, view.group, view.code);
      if (!entry) return;
      var newIdx = dir === 'next' ? entry.idx + 1 : entry.idx - 1;
      var target = entry.siblings[newIdx];
      if (target) replaceTop({ type:'item', cat: view.cat, group: view.group, code: target.code });
    });
  });
}

/* ============ Init: fetch data, then boot the app ============ */
function init(){
  app.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;min-height:100vh;background:var(--ink)">' +
    '<div style="color:#F4EFDF;font-family:Cairo,sans-serif;font-size:14px;opacity:.85">جاري تحميل المنصة...</div></div>';
  fetch('data.json')
    .then(function(r){
      if (!r.ok) throw new Error('bad response');
      return r.json();
    })
    .then(function(json){
      DATA = json;
      buildIndex();
      render();
    })
    .catch(function(err){
      app.innerHTML = '<div style="padding:40px 20px;text-align:center;font-family:Cairo,sans-serif;color:#8a2f2f">' +
        'تعذّر تحميل بيانات المنصة (data.json). تأكدي من فتح الملف عبر خادم ويب (مثل GitHub Pages) وليس مباشرة من الجهاز.</div>';
      console.error(err);
    });
}

if ('serviceWorker' in navigator){
  window.addEventListener('load', function(){
    navigator.serviceWorker.register('sw.js').catch(function(e){ console.warn('SW registration failed', e); });
  });
}

init();
