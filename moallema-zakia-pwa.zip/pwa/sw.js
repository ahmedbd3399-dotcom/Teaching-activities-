// منصة المعلمة الذكية — Service Worker
// كاش شامل لكل ملفات التطبيق حتى يشتغل بدون إنترنت بعد أول زيارة/تثبيت
const CACHE_VERSION = 'v1.0.0';
const CACHE_NAME = 'moallema-zakia-' + CACHE_VERSION;

const CORE_ASSETS = [
  './',
  './index.html',
  './app.js',
  './styles.css',
  './data.json',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-512-maskable.png',
  './assets/guide/01.jpg',
  './assets/guide/02.jpg',
  './assets/guide/03.jpg',
  './assets/guide/04.jpg',
  './assets/guide/05.jpg',
  './assets/guide/06.jpg',
  './assets/guide/07.jpg',
  './assets/guide/08.jpg',
  './assets/guide/09.jpg',
  './assets/guide/10.jpg'
];

self.addEventListener('install', function(event){
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache){
      return cache.addAll(CORE_ASSETS);
    }).then(function(){ return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function(event){
  event.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys.filter(function(k){ return k.indexOf('moallema-zakia-') === 0 && k !== CACHE_NAME; })
            .map(function(k){ return caches.delete(k); })
      );
    }).then(function(){ return self.clients.claim(); })
  );
});

// استراتيجية: كاش أولاً، ثم الشبكة كنسخة احتياطية (وتحديث الكاش في الخلفية)
self.addEventListener('fetch', function(event){
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then(function(cached){
      var networkFetch = fetch(event.request).then(function(response){
        if (response && response.status === 200 && response.type === 'basic'){
          var copy = response.clone();
          caches.open(CACHE_NAME).then(function(cache){ cache.put(event.request, copy); });
        }
        return response;
      }).catch(function(){ return cached; });
      return cached || networkFetch;
    })
  );
});
